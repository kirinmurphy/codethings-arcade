import { initializeCanvas } from "./initializeCanvas.js";

let gameHelper;

export function createCanvasHelper (props) {
  gameHelper = initializeCanvas(props);
};

export function useCanvasHelper() {
  return gameHelper;
};
