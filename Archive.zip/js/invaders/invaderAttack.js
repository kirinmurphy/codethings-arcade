import { STATUS } from "../helpers/constants.js";
import { BATTLE_PROPS } from "../helpers/getBattleHelper.js";


export function invaderAttack({ screenHelper }) {
  const { screenSettings, battleHelper, mapCoordinates, mapObservers } = screenHelper;
  const { shipSize } = screenSettings; 
  const { get, updateState, clearStateMap, deleteFromState } = battleHelper;
  const { getCell, isAt } = mapObservers;
  const { shooters, liveBullets } = get();

  mapCoordinates.clearStatus(STATUS.invaderShot);

  for (const shooterPos of shooters.values()) {
    const distanceOffset = { xDistance: shipSize/2, yDistance: shipSize };
    const shipTurretPos = getCell.at(shooterPos, distanceOffset);
    updateState({ map: BATTLE_PROPS.liveBullets, key: shipTurretPos, value: true });    
  }

  clearStateMap({ map: BATTLE_PROPS.shooters });

  for (const bulletPos of liveBullets.keys()) {
    deleteFromState({ map: BATTLE_PROPS.liveBullets, key: bulletPos });

    const moreToGo = !isAt.bottomRow({ position: bulletPos });
    console.log('------------- isAt.bott', isAt.bottomRow({ position: bulletPos });
    if ( moreToGo ) {
      const newPos = getCell.below(bulletPos);
      // THIS IS BLOWING UP!,  
      updateState({ map: BATTLE_PROPS.liveBullets, key: newPos, value: true });
      // mapCoordinates.setStatus({ position: newPos, status: STATUS.invaderShot });
      console.log('moved: ', liveBullets.size, newPos);
    } 
  }
}

